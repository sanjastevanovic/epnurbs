# epnurbs

This package contains a few methods that enable one to add shading surfaces for walls directly in EnergyPlus .idf/.imf file. Methods rely on *eppy* to manage .idf files and *NURBS-Python* to create nurbs curves.

